package com.mytix.cinema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyTixCinemaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyTixCinemaApplication.class, args);
	}

}
